# RTS ACTION LOG 0003
University Outreach (Initial Contact)

## Log Type
Action Log / External Communication

## Date
2026-02-XX

## Actor
山内 延天（ヤマウチ ノブタカ）
RTS Originator

## Action Summary
防災・有事対応における判断プロセスの記録・検証に関する研究相談として、
以下の大学教員に対し、個別に相談メールを送付した。

## Actions Taken
- 琉球大学 工学部 社会基盤デザインコース
  - 神谷 大介 准教授：メール送付
  - 上地 安謙 助教：メール送付

## Materials Shared
- RTS GitHub Repository（リンクのみ）

## Current Status
- 送付完了
- 返信待ち（先方スケジュール依存）

## Notes
- 同時多発的なアプローチは避け、初期接触は琉球大学に限定
- 反応状況を見て次段（他大学）を判断する
